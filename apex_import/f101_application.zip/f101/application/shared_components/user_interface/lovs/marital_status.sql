prompt --application/shared_components/user_interface/lovs/marital_status
begin
--   Manifest
--     MARITAL_STATUS
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>10107082786587856
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'MLOPSU1'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(12107498711310333)
,p_lov_name=>'MARITAL_STATUS'
,p_lov_query=>'select distinct MARITAL_STATUS as dv, MARITAL_STATUS as rv from credit_scoring'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'CREDIT_SCORING'
,p_return_column_name=>'RV'
,p_display_column_name=>'DV'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
