prompt --application/shared_components/remote_servers/modeldeployment_us_ashburn_1_oci_customer_oci_com
begin
--   Manifest
--     REMOTE SERVER: modeldeployment-us-ashburn-1-oci-customer-oci-com
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>10107082786587856
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'MLOPSU1'
);
wwv_flow_api.create_remote_server(
 p_id=>wwv_flow_api.id(11282619029462769)
,p_name=>'modeldeployment-us-ashburn-1-oci-customer-oci-com'
,p_static_id=>'modeldeployment_us_ashburn_1_oci_customer_oci_com'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('modeldeployment_us_ashburn_1_oci_customer_oci_com'),'https://modeldeployment.us-ashburn-1.oci.customer-oci.com/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('modeldeployment_us_ashburn_1_oci_customer_oci_com'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('modeldeployment_us_ashburn_1_oci_customer_oci_com'),'')
,p_prompt_on_install=>false
);
wwv_flow_api.component_end;
end;
/
