prompt --application/shared_components/files/app_101_logo_svg
begin
--   Manifest
--     APP STATIC FILES: 101
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>10107082786587856
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'MLOPSU1'
);
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '3C73766720786D6C6E733D27687474703A2F2F7777772E77332E6F72672F323030302F737667272077696474683D27333227206865696768743D273235273E3C7061746820643D274D392E392032302E31632D352E3520302D392E392D342E342D392E39';
wwv_flow_api.g_varchar2_table(2) := '2D392E3953342E342E3320392E392E336831312E3663352E35203020392E3920342E3420392E3920392E39732D342E3420392E392D392E3920392E3948392E396D31312E332D332E3563332E36203020362E342D322E3920362E342D362E3420302D332E';
wwv_flow_api.g_varchar2_table(3) := '362D322E392D362E342D362E342D362E34682D3131632D332E3620302D362E3420322E392D362E3420362E3473322E3920362E3420362E3420362E34683131272066696C6C3D2723433734363334272F3E3C2F7376673E';
wwv_flow_api.create_app_static_file(
 p_id=>wwv_flow_api.id(11384738137973010)
,p_file_name=>'app-101-logo.svg'
,p_mime_type=>'image/svg+xml'
,p_file_content => wwv_flow_api.varchar2_to_blob(wwv_flow_api.g_varchar2_table)
);
wwv_flow_api.component_end;
end;
/
