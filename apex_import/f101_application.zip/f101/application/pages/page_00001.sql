prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>10107082786587856
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'MLOPSU1'
);
wwv_flow_api.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_api.id(10280820922164845)
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Client Advisory'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script src="#APP_IMAGES#scripts/settings.js"></script>',
'<script src="#APP_IMAGES#scripts/web-sdk.js" onload="initSDK(''Bots'')"></script>'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(window).on("theme42ready", function()',
'    {',
'        if ($("body").hasClass("js-navExpanded"))',
'        {',
'            $("#t_Button_navControl").click();',
'        }',
'    }',
');'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.oda-chat-button {',
'    // height:  76px;',
'    // width:   64px;',
'    outline: none;',
'    background-color: transparent;',
'    box-shadow: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'MLOPSU1'
,p_last_upd_yyyymmddhh24miss=>'20211111103224'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10303316581164993)
,p_plug_name=>'Hello &APP_USER., what would you like to do today?'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon'
,p_plug_template=>wwv_flow_api.id(10181442158164702)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10653875761165815)
,p_plug_name=>'Page Navigation'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--featured t-Cards--block force-fa-lg:t-Cards--displayIcons:t-Cards--spanHorizontally:t-Cards--hideBody:t-Cards--animColorFill'
,p_plug_template=>wwv_flow_api.id(10163426796164692)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(10652497721165811)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(10232169408164752)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13054785271000911)
,p_plug_name=>'ADS'
,p_region_template_options=>'#DEFAULT#:js-cycle5s:t-Region--carouselSpin:t-Region--removeHeader:t-Region--accent1:t-Region--hiddenOverflow'
,p_plug_template=>wwv_flow_api.id(10164467262164692)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13055375453000917)
,p_plug_name=>'ACME Finance'
,p_parent_plug_id=>wwv_flow_api.id(13054785271000911)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(10191261649164709)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13055436263000918)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_api.id(13054785271000911)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(10191261649164709)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13055573123000919)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_api.id(13054785271000911)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(10160261436164689)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13054849895000912)
,p_name=>'P1_NEW'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(13055573123000919)
,p_source=>'#APP_IMAGES#img03.png'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_field_template=>wwv_flow_api.id(10253842971164772)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attribute_01=>'URL'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13055091732000914)
,p_name=>'P1_NEW_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(13055436263000918)
,p_source=>'#APP_IMAGES#img04.png'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_field_template=>wwv_flow_api.id(10253842971164772)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'URL'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13055130939000915)
,p_name=>'P1_NEW_2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(13055375453000917)
,p_source=>'#APP_IMAGES#img05.png'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_field_template=>wwv_flow_api.id(10253842971164772)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'URL'
);
wwv_flow_api.component_end;
end;
/
