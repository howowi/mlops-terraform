prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>10107082786587856
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'MLOPSU1'
);
wwv_flow_api.create_page(
 p_id=>10
,p_user_interface_id=>wwv_flow_api.id(10280820922164845)
,p_name=>'Loan Application'
,p_alias=>'LOAN-APPLICATION'
,p_step_title=>'Loan Application'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script src="#APP_IMAGES#scripts/settings.js"></script>',
'<script src="#APP_IMAGES#scripts/web-sdk.js" onload="initSDK(''Bots'')"></script>'))
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(window).on("theme42ready", function()',
'    {',
'        if ($("body").hasClass("js-navExpanded"))',
'        {',
'            $("#t_Button_navControl").click();',
'        }',
'    }',
');'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.oda-chat-button {',
'    // height:  76px;',
'    // width:   64px;',
'    outline: none;',
'    background-color: transparent;',
'    box-shadow: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'MLOPSU1'
,p_last_upd_yyyymmddhh24miss=>'20220224091922'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12154955933654144)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(10200658791164714)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(10133634643164629)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(10257757235164779)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12155528180654389)
,p_plug_name=>'Loan Application Details'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(10191261649164709)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'APPLICANTS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12219682384431018)
,p_plug_name=>'Message'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_api.id(10156569663164677)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12166836434654404)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(12155528180654389)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(10256380323164777)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P10_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12165625463654402)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(12155528180654389)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(10256380323164777)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(11755577016263228)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(12155528180654389)
,p_button_name=>'CheckEligibility'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight:t-Button--hoverIconPush'
,p_button_template_id=>wwv_flow_api.id(10256441596164777)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Smart Approval'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-code-group'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12167293833654405)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(12155528180654389)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(10256441596164777)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit Application'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P10_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_icon_css_classes=>'fa-send'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12166489870654404)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(12155528180654389)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(10256380323164777)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P10_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(12167572064654405)
,p_branch_action=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11756907794263242)
,p_name=>'P10_AGE'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(12155528180654389)
,p_item_source_plug_id=>wwv_flow_api.id(12155528180654389)
,p_prompt=>'Age'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_source=>'AGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(10253842971164772)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11757092936263243)
,p_name=>'P10_RESULT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(12155528180654389)
,p_item_source_plug_id=>wwv_flow_api.id(12155528180654389)
,p_source=>'RESULT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12155860688654389)
,p_name=>'P10_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(12155528180654389)
,p_item_source_plug_id=>wwv_flow_api.id(12155528180654389)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12156259918654391)
,p_name=>'P10_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(12155528180654389)
,p_item_source_plug_id=>wwv_flow_api.id(12155528180654389)
,p_item_default=>'&APP_USER.'
,p_prompt=>'Full Name'
,p_source=>'NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(10253842971164772)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12156667077654394)
,p_name=>'P10_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(12155528180654389)
,p_item_source_plug_id=>wwv_flow_api.id(12155528180654389)
,p_prompt=>'Email'
,p_source=>'EMAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(10253842971164772)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12157068511654394)
,p_name=>'P10_MARITAL_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(12155528180654389)
,p_item_source_plug_id=>wwv_flow_api.id(12155528180654389)
,p_prompt=>'Marital Status'
,p_source=>'MARITAL_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    MARITAL_STATUS as dv,',
'    MARITAL_STATUS as rv',
' from MARITAL_STATUS_LOOKUP'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(10253842971164772)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12157450603654394)
,p_name=>'P10_EDUCATION_LEVEL'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(12155528180654389)
,p_item_source_plug_id=>wwv_flow_api.id(12155528180654389)
,p_prompt=>'Education Level'
,p_source=>'EDUCATION_LEVEL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    EDUCATION_LEVEL as dv,',
'    EDUCATION_LEVEL as rv',
' from EDUCATION_LEVEL_LOOKUP'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(10253842971164772)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12157886285654395)
,p_name=>'P10_RESIDENTAL_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(12155528180654389)
,p_item_source_plug_id=>wwv_flow_api.id(12155528180654389)
,p_prompt=>'Residental Status'
,p_source=>'RESIDENTAL_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    RESIDENTAL_STATUS as dv,',
'    RESIDENTAL_STATUS as rv',
' from RESIDENTAL_STATUS_LOOKUP'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(10253842971164772)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12158290811654395)
,p_name=>'P10_LOAN_AMOUNT'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(12155528180654389)
,p_item_source_plug_id=>wwv_flow_api.id(12155528180654389)
,p_prompt=>'Loan Amount'
,p_source=>'LOAN_AMOUNT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(10253842971164772)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12158600742654395)
,p_name=>'P10_INCOME'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(12155528180654389)
,p_item_source_plug_id=>wwv_flow_api.id(12155528180654389)
,p_prompt=>'Income'
,p_source=>'INCOME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(10253842971164772)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12159054740654396)
,p_name=>'P10_GENDER'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(12155528180654389)
,p_item_source_plug_id=>wwv_flow_api.id(12155528180654389)
,p_prompt=>'Gender'
,p_source=>'GENDER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    GENDER as dv,',
'    GENDER as rv',
' from GENDER_LOOKUP'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(10253842971164772)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12159453650654396)
,p_name=>'P10_NUMBER_OF_PRIOR_LOANS'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(12155528180654389)
,p_item_source_plug_id=>wwv_flow_api.id(12155528180654389)
,p_prompt=>'Number Of Prior Loans'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_source=>'NUMBER_OF_PRIOR_LOANS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(10253842971164772)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12159890794654396)
,p_name=>'P10_TENURE'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(12155528180654389)
,p_item_source_plug_id=>wwv_flow_api.id(12155528180654389)
,p_prompt=>'Tenure (Months)'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_source=>'TENURE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(10253842971164772)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12160216077654396)
,p_name=>'P10_PRESENT_EMPLOYMENT_SINCE'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(12155528180654389)
,p_item_source_plug_id=>wwv_flow_api.id(12155528180654389)
,p_prompt=>'Present Employment Since'
,p_source=>'PRESENT_EMPLOYMENT_SINCE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    PRESENT_EMPLOYMENT_SINCE as dv,',
'    PRESENT_EMPLOYMENT_SINCE as rv',
' from PRESENT_EMPLOYMENT_SINCE_LOOKUP'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(10253842971164772)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12160671787654397)
,p_name=>'P10_FAMILY_SIZE'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(12155528180654389)
,p_item_source_plug_id=>wwv_flow_api.id(12155528180654389)
,p_prompt=>'Family Size'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_source=>'FAMILY_SIZE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(10253842971164772)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12161066831654397)
,p_name=>'P10_OCCUPATION'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(12155528180654389)
,p_item_source_plug_id=>wwv_flow_api.id(12155528180654389)
,p_prompt=>'Occupation'
,p_source=>'OCCUPATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    OCCUPATION as dv,',
'    OCCUPATION as rv',
' from OCCUPATION_LOOKUP'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(10253842971164772)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(12219205972431014)
,p_name=>'P10_MESSAGE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(12219682384431018)
,p_prompt=>'Message'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(10253842971164772)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(13054043911000904)
,p_validation_name=>'MaxLoanAmount'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    if :P10_LOAN_AMOUNT > 10000 then',
'        return ''Max Loan Amount Exceeded'';',
'    end if;',
'    return null;',
'end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(11755616301263229)
,p_name=>'CheckML'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(11755577016263228)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(11755728639263230)
,p_event_id=>wwv_flow_api.id(11755616301263229)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'l_clob          CLOB;',
'l_request_clob  CLOB;',
'l_rest_url      VARCHAR2(1000); ',
'V_RESULT_NAME   VARCHAR2 (500);',
'',
'BEGIN',
'',
'IF (:P10_MARITAL_STATUS IS NOT NULL and :P10_EDUCATION_LEVEL IS NOT NULL and :P10_RESIDENTAL_STATUS IS NOT NULL and :P10_LOAN_AMOUNT IS NOT NULL and :P10_INCOME IS NOT NULL and :P10_GENDER IS NOT NULL and :P10_NUMBER_OF_PRIOR_LOANS IS NOT NULL and :P'
||'10_AGE IS NOT NULL and :P10_TENURE IS NOT NULL and :P10_PRESENT_EMPLOYMENT_SINCE IS NOT NULL and :P10_FAMILY_SIZE IS NOT NULL and :P10_OCCUPATION IS NOT NULL) THEN',
'',
'apex_web_service.g_request_headers(1).name  := ''Content-Type'';  ',
'apex_web_service.g_request_headers(1).value := ''application/json'';',
'l_request_clob := ''{"MARITAL_STATUS":{"4":"''||:P10_MARITAL_STATUS||''"},"EDUCATION_LEVEL":{"4":"''||:P10_EDUCATION_LEVEL||''"},"RESIDENTAL_STATUS":{"4":"''||:P10_RESIDENTAL_STATUS||''"},"LOAN_AMOUNT":{"4":''||:P10_LOAN_AMOUNT||''},"INCOME":{"4":''||:P10_INCO'
||'ME||''},"GENDER":{"4":"''||:P10_GENDER||''"},"NUMBER_OF_PRIOR_LOANS":{"4":''||:P10_NUMBER_OF_PRIOR_LOANS||''},"AGE":{"4":''||:P10_AGE||''},"TENURE":{"4":''||:P10_TENURE||''},"PRESENT_EMPLOYMENT_SINCE":{"4":"''||:P10_PRESENT_EMPLOYMENT_SINCE||''"},"FAMILY_SIZE":'
||'{"4":''||:P10_FAMILY_SIZE||''},"OCCUPATION":{"4":"''||:P10_OCCUPATION||''"}}'';',
'',
'-- l_rest_url  := ''https://nw566tycasrsavuvlbiyszomry.apigateway.us-phoenix-1.oci.customer-oci.com/v1/predict'';',
'l_rest_url  := ''https://kp7cp366vte53yrppdybs6keji.apigateway.us-phoenix-1.oci.customer-oci.com/v1/predict'';',
'  -- Get the XML response from the web service.',
'  l_clob := APEX_WEB_SERVICE.make_rest_request(',
'    p_url         => l_rest_url,',
'    p_http_method => ''POST'',',
'    p_body => l_request_clob',
'    -- ,p_credential_static_id => ''OCI_REST_API''',
'  );',
'    ',
'    --:P12_RESULT := ''Success'';',
'EXECUTE IMMEDIATE ''SELECT JSON_VALUE(:1,''''$.'' || ''prediction[0]'' || '''''')  FROM DUAL''',
'      INTO V_RESULT_NAME',
'      USING l_clob;',
'',
'   --DBMS_OUTPUT.PUT_LINE (V_RESULT_NAME );',
'',
'   IF V_RESULT_NAME = ''0'' THEN',
'      :P10_RESULT := ''Denied'';',
'      :P10_MESSAGE := ''Your loan has been Denied, however you can still submit your application for review.'';',
'      --:P10_MESSAGE := ''In Principle Approval: Denied ('' || l_clob || l_request_clob || '')'';',
'',
'   ELSE',
'      :P10_RESULT := ''Approved'';',
'      :P10_MESSAGE := ''Your loan has been Approved in principle, you can proceed to submit your application.'';',
'      --:P10_MESSAGE := ''In Principle Approval: Approved ('' || l_clob || l_request_clob || '')'';',
'',
'   END IF;',
'',
'   -- DBMS_OUTPUT.PUT_LINE(l_clob || l_request_clob);',
'',
'-- exception when no_data_found then',
'--             :P10_RESULT := ''No data Found'';',
'',
'ELSE',
' :P10_RESULT := ''ERROR'';',
' :P10_MESSAGE := ''All Fields are required.'';',
'',
'END IF;',
'',
'',
'END;'))
,p_attribute_02=>'P10_AGE,P10_GENDER,P10_MARITAL_STATUS,P10_FAMILY_SIZE,P10_RESIDENTAL_STATUS,P10_EDUCATION_LEVEL,P10_OCCUPATION,P10_INCOME,P10_PRESENT_EMPLOYMENT_SINCE,P10_LOAN_AMOUNT,P10_TENURE,P10_NUMBER_OF_PRIOR_LOANS'
,p_attribute_03=>'P10_RESULT,P10_MESSAGE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(11755803439263231)
,p_event_id=>wwv_flow_api.id(11755616301263229)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(12219682384431018)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(11757629003263249)
,p_event_id=>wwv_flow_api.id(11755616301263229)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(12167293833654405)
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P10_RESULT'
,p_client_condition_expression=>'Approved'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(11756112070263234)
,p_name=>'Hide RESULT'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(11756254634263235)
,p_event_id=>wwv_flow_api.id(11756112070263234)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(12219682384431018)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(11757115592263244)
,p_event_id=>wwv_flow_api.id(11756112070263234)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(12167293833654405)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(12219361527431015)
,p_name=>'clearMessage'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(12219428330431016)
,p_event_id=>wwv_flow_api.id(12219361527431015)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P10_MESSAGE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(12168433348654406)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(12155528180654389)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Loan Application'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Your Application has been submitted.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(12168069631654406)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(12155528180654389)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Loan Application'
);
wwv_flow_api.component_end;
end;
/
